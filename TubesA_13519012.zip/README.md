# tubes_machine_learning
Tubes A, B, dan C Machine Learnig
